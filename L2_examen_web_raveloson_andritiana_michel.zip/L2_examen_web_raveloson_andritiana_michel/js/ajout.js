document.querySelector('.alerte').textContent = 'veuillez tout remplir'
let form = document.querySelector('form');

let inputs = document.querySelectorAll('form input')

document.querySelector('input[type="submit"]').addEventListener('click',function(e){
    if(verifier_tout() != 0){
        console.log('data incomplete')
    }
    else{
        console.log('tout les donnes seront enregistres')
        let data = JSON.parse(localStorage.getItem('mes_livres'))
        let chaine = {
            titre:'',
            auteurs:'',
            isbn:'',
            image:'../image/bd2.jpg',
            editeur:'',
            datePublication:'',
            genre:'',
            resume:'',
            langue:'',
            nombrePages:'',
            disponibilite:true,
            etat:'bon',
            emplacement:'libre'
        }
        inputs.forEach((element,index)=>{

            if(index == 0){
                chaine.titre = element.value
            }
            else if(index == 1){
                chaine.auteurs = element.value
            }
            else if(index == 2){
                chaine.isbn = element.value
            }
            else if(index == 3){
                chaine.image = "../image/" + element.value
            }
            else if(index == 4){
                chaine.editeur = element.value
            }
            else if(index == 5){
                chaine.datePublication = element.value
            }
            else if(index == 6){
                chaine.genre = element.value
            }
            else if(index == 7){
                chaine.nombrePages = element.value
            }
        })
        let details = document.querySelector('textarea').value
        chaine.resume = details
        let langue = document.querySelector('select').value
        chaine.langue = langue
        data['livres'].push(chaine)
        localStorage.setItem('mes_livres',JSON.stringify(data))
    }
})

function verifier_tout(){
    let cpt = 0
    inputs.forEach((element)=>{
        if(element.value == 0){
            cpt++;
        }
    })
    if(document.querySelector('textarea').value.length == 0){
        cpt++;
    }
    return cpt;
}

inputs.forEach((element)=>{
    element.addEventListener('change',function(){
        let nb = verifier_tout();
        if(nb){
            document.querySelector('.alerte').textContent = `${nb} element(s) ne sont pas encore remplis`
            document.querySelector('.alerte').style.color = 'red'
        }
        else{
            document.querySelector('.alerte').textContent = `tout est rempli`
            document.querySelector('.alerte').style.color = 'green'
        }
    })
})