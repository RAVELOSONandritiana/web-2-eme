window.onload = function () {
    document.querySelector('.details').style.display = 'none'
    fetch('../livres.json')
        .then((response) => {
            return response.json()
        })
        .then((data) => {
            //console.log(data['livres'][0]['titre'])
            //acces a un element du fichier JSON
            if (!localStorage.getItem('mes_livres')) {
                localStorage.setItem('mes_livres', JSON.stringify(data))
            }
            let list_livres = JSON.parse(localStorage.getItem('mes_livres'))
            createBook(list_livres)
        })
}

function createBook(l) {
    let taille = l['livres'].length
    for (let i = 0; i < taille; i++) {
        let div = document.createElement('div')
        div.setAttribute('class', 'livre')
        let image = document.createElement('img')
        image.src = l["livres"][i]['image']
        let h3 = document.createElement('h3')
        h3.textContent = l["livres"][i]['titre']
        let h5 = document.createElement('h2')
        h5.textContent = l["livres"][i]['datePublication']

        let supprimer = document.createElement('button')
        supprimer.setAttribute('class', 'button')
        supprimer.textContent = 'supprimer'
        supprimer.addEventListener('click', function (e) {
            let tab = JSON.parse(localStorage.getItem('mes_livres'))
            for (let index = 0; index < taille; index++) {
                // console.log(l['livres'][index].titre)
                console.log(this.parentElement.children[index].textContent)
                if (l['livres'][i].titre == this.parentElement.children[index].textContent) {
                    removeWithTitle(this.parentElement.children[index].textContent)
                    // console.log(tab['livres'][index])//index a supprimer dans le localstorage
                    tab['livres'].splice(i, 1)
                    localStorage.setItem('mes_livres', JSON.stringify(tab))
                }
            }
            document.querySelector('main').removeChild(this.parentElement)
        })
        let details = document.createElement('button')
        details.setAttribute('class', 'button')
        details.textContent = 'details'
        details.addEventListener('click', function (e) {
            document.querySelector('.details').style.display = 'block'
            document.querySelector('.details').innerHTML = `<p>Titre</p><p>${l['livres'][i].titre}</p><br><p>Auteurs</p><p>${l['livres'][i].auteurs}</p><br><p>isbn</p><p>${l['livres'][i].isbn}</p><br><p>image</p><p>${l['livres'][i].image}</p><br><p>editeur</p><p>${l['livres'][i].editeur}</p><br><p>datePublication</p><p>${l['livres'][i].datePublication}</p><br><p>genre</p><p>${l['livres'][i].genre}</p><br><p>resume</p><p>${l['livres'][i].resume}</p><br><p>langue</p><p>${l['livres'][i].langue}</p><br><p>nombre de pages</p><p>${l['livres'][i].nombrePages}</p><br><p>disponiblite</p><p>${l['livres'][i].disponibilite}</p><br><p>etat</p><p>${l['livres'][i].etat}</p><br><p>empalcement</p><p>${l['livres'][i].emplacement}</p><br>`
            let index = 0
            for (let i of document.querySelectorAll('.details p')) {
                if (index % 2 == 0) {
                    i.style.color = 'red'
                    i.style.fontSize = '20px'
                }
                index++
            }
        })
        div.appendChild(image)
        div.appendChild(h3)
        div.appendChild(h5)
        div.appendChild(supprimer)
        div.appendChild(details)

        document.querySelector('main').appendChild(div)
    }
}

document.querySelector('input[type="search"]').addEventListener('input', function (e) {
    let element = e.currentTarget.value
    let data = elementCorrespondant(element)
    console.log(data)
    createBook2(data)
})

function elementCorrespondant(titre) {
    let data = JSON.parse(localStorage.getItem('mes_livres'))
    return data['livres'].filter((e) => e.titre.toLowerCase().includes(titre.toLowerCase()))
}

function indexTitle(title) {//retourne l index d un livre dans le localstorage
    let data = JSON.parse(localStorage.getItem('mes_livres'))
    let nb_livres = data['livres'].length
    for (let i = 0; i < nb_livres; i++) {
        if (data['livres'][i].titre == title) {
            return i
        }
    }
    return list_index
}

function removeWithTitle(title) {
    let index = indexTitle(title)
    let data = JSON.parse(localStorage.getItem('mes_livres'))
    data['livres'].slice(index, 1)
}

function createBook2(l) {
    let taille = l.length
    for (let element of document.querySelectorAll('.livre')) {
        document.querySelector('main').removeChild(element)
    }
    for (let i = 0; i < taille; i++) {
        let div = document.createElement('div')
        div.setAttribute('class', 'livre')
        let image = document.createElement('img')
        image.src = l[i]['image']
        let h3 = document.createElement('h3')
        h3.textContent = l[i]['titre']
        let supprimer = document.createElement('button')
        supprimer.setAttribute('class', 'button')
        supprimer.textContent = 'supprimer'

        supprimer.addEventListener('click', function (e) {
            let tab = JSON.parse(localStorage.getItem('mes_livres'))
            for (let index = 0; index < taille; index++) {
                // console.log(l['livres'][index].titre)
                console.log(this.parentElement.children[index].textContent)
                if (l['livres'][i].titre == this.parentElement.children[index].textContent) {
                    removeWithTitle(this.parentElement.children[index].textContent)
                    // console.log(tab['livres'][index])//index a supprimer dans le localstorage
                    tab['livres'].splice(i, 1)
                    localStorage.setItem('mes_livres', JSON.stringify(tab))
                }
            }
            document.querySelector('main').removeChild(this.parentElement)
        })
        let details = document.createElement('button')
        details.setAttribute('class', 'button')
        details.textContent = 'details'

        details.addEventListener('click', function (e) {
            document.querySelector('.details').style.display = 'block'
            document.querySelector('.details').innerHTML = `<p>Titre</p><p>${l['livres'][i].titre}</p><br><p>Auteurs</p><p>${l['livres'][i].auteurs}</p><br><p>isbn</p><p>${l['livres'][i].isbn}</p><br><p>image</p><p>${l['livres'][i].image}</p><br><p>editeur</p><p>${l['livres'][i].editeur}</p><br><p>datePublication</p><p>${l['livres'][i].datePublication}</p><br><p>genre</p><p>${l['livres'][i].genre}</p><br><p>resume</p><p>${l['livres'][i].resume}</p><br><p>langue</p><p>${l['livres'][i].langue}</p><br><p>nombre de pages</p><p>${l['livres'][i].nombrePages}</p><br><p>disponiblite</p><p>${l['livres'][i].disponibilite}</p><br><p>etat</p><p>${l['livres'][i].etat}</p><br><p>empalcement</p><p>${l['livres'][i].emplacement}</p><br>`
            let index = 0
            for (let i of document.querySelectorAll('.details p')) {
                if (index % 2 == 0) {
                    i.style.color = 'red'
                    i.style.fontSize = '20px'
                }
                index++
            }
        })
        div.appendChild(image)
        div.appendChild(h3)
        div.appendChild(supprimer)
        div.appendChild(details)
        document.querySelector('main').appendChild(div)
    }
}